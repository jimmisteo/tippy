package com.example.firstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView

private const val TAG = "MainActivity"
private const val INITIAL_TIP_PERCENT = 15
class MainActivity : AppCompatActivity() {

    private lateinit var baseamount: EditText
    private lateinit var seekBar2: SeekBar
    private lateinit var tvlabel: TextView
    private lateinit var tipamount: TextView
    private lateinit var totalAmount: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        baseamount = findViewById(R.id.baseamount)
        seekBar2 = findViewById(R.id.seekBar2)
        tvlabel = findViewById(R.id.tvlabel)
        tipamount = findViewById(R.id.tipamount)
        totalAmount = findViewById(R.id.totalAmount)
        seekBar2.progress = INITIAL_TIP_PERCENT
        tvlabel.text = "$INITIAL_TIP_PERCENT%"

        seekBar2.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                Log.i(TAG, "onProgressChanged $progress")
                tvlabel.text = "$progress%"
                computeTipAndTotal()
            }

            override fun onStartTrackingTouch(p0: SeekBar?){}

            override fun onStopTrackingTouch(p0: SeekBar?) {}

        })
        baseamount.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun afterTextChanged(s: Editable?) {
                Log.i(TAG,"afterTextChanged $s")
                computeTipAndTotal()
            }

        })
    }

    private fun computeTipAndTotal() {

        if(baseamount.text.isEmpty()){
            tipamount.text = ""
            totalAmount.text = ""
            return

        }
        val baseAmount = baseamount.text.toString().toDouble()
        val TipPercent = seekBar2.progress

        val TipAmount = baseAmount * TipPercent / 100
        val TotalAmount = baseAmount + TipAmount
        tipamount.text = "%.2f".format(TipAmount)
        totalAmount.text = "%.2f".format(TotalAmount)
    }
}